﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Daguman_FinalProject
{
    public partial class Form1 : Form
    {
        private SqlConnection connection;
        public Form1()
        {
            InitializeComponent();
            connection = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"" + database() + "\";Integrated Security=True");
        }

        public static string database()
        {
            string filePath = Path.Combine(Path.GetDirectoryName(Path.GetDirectoryName(Path.GetDirectoryName(
                AppDomain.CurrentDomain.BaseDirectory))), "Database1.mdf");
            if (File.Exists(filePath))
                return filePath;
            throw new FileNotFoundException($"The database was not found.");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'database1DataSet1.Students' table. You can move, or remove it, as needed.
            this.studentsTableAdapter.Fill(this.database1DataSet1.Students);
        }

        private void LoadStudentRecords()
        {
            try
            {
                connection.Open();

                string query = "SELECT * FROM Students";
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                dataGridView1.DataSource = dataTable;
                connection.Close();
            }
            catch (Exception ex)
            {
                connection.Close();
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                string studentID = textBox1.Text;
                string lastName = textBox2.Text;
                string firstName = textBox3.Text;
                string emailAddress = textBox4.Text;
                string course = textBox5.Text;
                double gpa = Convert.ToDouble(textBox6.Text);



                string query = "INSERT INTO Students (id, lastname, firstname, email, course, gpa) " +
                               "VALUES (@id, @lastname, @firstname, @email, @course, @gpa)";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@id", studentID);
                command.Parameters.AddWithValue("@lastname", lastName);
                command.Parameters.AddWithValue("@firstname", firstName);
                command.Parameters.AddWithValue("@email", emailAddress);
                command.Parameters.AddWithValue("@course", course);
                command.Parameters.AddWithValue("@gpa", gpa);

                command.ExecuteNonQuery();

                MessageBox.Show("Student added successfully.");
                connection.Close();
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                LoadStudentRecords();
            }
            catch (Exception ex)
            {
                connection.Close();
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                string studentID = textBox1.Text;

                string query = "SELECT * FROM Students WHERE id = @StudentID";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@StudentID", studentID);
                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    textBox2.Text = reader["lastname"].ToString();
                    textBox3.Text = reader["firstname"].ToString();
                    textBox4.Text = reader["email"].ToString();
                    textBox5.Text = reader["course"].ToString();
                    textBox6.Text = reader["gpa"].ToString();
                }
                else
                {
                    MessageBox.Show("Student not found.");
                }
                connection.Close();
                reader.Close();
            }
            catch (Exception ex)
            {
                connection.Close();
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                string studentID = textBox1.Text;
                string lastName = textBox2.Text;
                string firstName = textBox3.Text;
                string emailAddress = textBox4.Text;
                string course = textBox5.Text;
                double gpa = Convert.ToDouble(textBox6.Text);

                string query = "UPDATE Students SET lastname = @LastName, firstname = @FirstName, " +
                               "email = @Email, course = @Course, gpa = @GPA " +
                               "WHERE id = @StudentID";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@LastName", lastName);
                command.Parameters.AddWithValue("@FirstName", firstName);
                command.Parameters.AddWithValue("@Email", emailAddress);
                command.Parameters.AddWithValue("@Course", course);
                command.Parameters.AddWithValue("@GPA", gpa);
                command.Parameters.AddWithValue("@StudentID", studentID);

                int rowsAffected = command.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    connection.Close();
                    MessageBox.Show("Student updated successfully.");
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox3.Clear();
                    textBox4.Clear();
                    textBox5.Clear();
                    textBox6.Clear();
                    LoadStudentRecords();
                }
                else
                {
                    MessageBox.Show("Student not found.");
                }
            }
            catch (Exception ex)
            {
                connection.Close();
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                string studentID = textBox1.Text;

                string query = "DELETE FROM Students WHERE id = @StudentID";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@StudentID", studentID);

                int rowsAffected = command.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Student deleted successfully.");
                    connection.Close();
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox3.Clear();
                    textBox4.Clear();
                    textBox5.Clear();
                    textBox6.Clear();
                    LoadStudentRecords();
                }
                else
                {
                    MessageBox.Show("Student not found.");
                }
            }
            catch (Exception ex)
            {
                connection.Close();
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
